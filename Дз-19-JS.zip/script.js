
let club = prompt(`Как вас зовут?`)
let age 
let money

if (club == `A` && `a` || +prompt(`Сколько вам лет?`) >= 20  <= 40) {
    money = +prompt(`Сколько у тебя денег в кармане?`)
}

if (money >= 100) {
    console.log(club);
} else {
    alert(`Не тебе ещё!`)
}